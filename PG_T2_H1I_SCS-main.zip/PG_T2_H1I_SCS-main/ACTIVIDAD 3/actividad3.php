<?php
    function conversorBinario($num1){
        $resultado1=bindec($num1);
        return $resultado1;
    }

    function converorHexadecimal($num2){
        $resultado=hex2bin($num2);
        return $resultado;
    }

?>