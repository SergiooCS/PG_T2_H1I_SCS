<?php
    function conversorBinario($num1){
        echo bindec($num1);
        return $num1;
    }

    function converorDecimal($num2){
        echo decbin($num2);
        return $num2;
    }

?>