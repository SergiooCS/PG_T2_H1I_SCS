<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>T2 - H1 - ACTIVIDAD 3 - SCS</title>
</head>
<body>
    <h2>CONVERSOR DE BINARIO A DECIMAL</h2>
    <?php
    require_once("actividad3.php");
    echo "<h4>Conversor de binario a decimal</h4>";
    $binario=conversorBinario('10010110');
    echo "<br>";
    echo "<h4>Conversor de decimal a binario</h4>";
    $decimal=converorDecimal('255');

    ?>
</body>
</html>